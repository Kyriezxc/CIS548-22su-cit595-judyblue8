/* This is a reference socket server implementation that prints out the messages
 * received from clients.
 *
 * It takes two arguments:
 * - server address
 * - server port
 *
 * */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h> 

#include <sys/socket.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#define MAX_PENDING 10
#define MAX_LINE 100
#define MAX_CLIENT 100

void handle_first_shake(int port);
void handle_second_shake(int port);
int main(int argc, char *argv[]) {
  char *host_addr = "127.0.0.1";
  int port = atoi(argv[1]);

  /*setup passive open*/
  int s;
  if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
    perror("simplex-talk: socket");
    exit(1);
  }

  /* Config the server address */
  struct sockaddr_in sin;
  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = inet_addr(host_addr);
  sin.sin_port = htons(port);
  // Set all bits of the padding field to 0
  memset(sin.sin_zero, '\0', sizeof(sin.sin_zero));

  /* Bind the socket to the address */
  if ((bind(s, (struct sockaddr *)&sin, sizeof(sin))) < 0) {
    perror("simplex-talk: bind");
    exit(1);
  }

  // connections can be pending if many concurrent client requests
  listen(s, MAX_PENDING);

  int new_s;
  socklen_t len = sizeof(sin);

  //Create a client struct
  struct ClientState{
    int fd;
    int shake;
    int val;
  };
  
  //Create and initialize the client state array
  struct ClientState clientStateArray[MAX_CLIENT];
  //iterate through ClientStateArray to initialize all
  for (int i = 0; i < MAX_CLIENT; i++){
    struct ClientState client = {-1, -1, -1};
    clientStateArray[i] = client;
  }

  //set fd sets
  int fd_max = s;
  fd_set master_set;
  fd_set ready_set;
  //Set both fd_set to zero
  FD_ZERO(&master_set);
  FD_ZERO(&ready_set);
  
  //set s to non-blocking and add to master set
  if(fcntl(s, F_GETFL, 0) < 0){
    perror("Error: fcntl");
    exit(1);

  }
  FD_SET(s, &master_set);

  while(1){

    //copy master_set to ready_set
    ready_set = master_set;

    //Use select() 0n ready_set
    if(select(fd_max + 1, &ready_set, NULL, NULL, NULL) <= 0){
      perror("Error:select");
      exit(1);
    }

    for(int i = 0; i <= fd_max; i++){
      //Check if the fd at index is set
      if(FD_ISSET(i, &ready_set)){
        if(i == s){
          //means new ports are ready, set up new port
          int new_s = accept(s, (struct sockaddr *)&sin, &len);
          if(new_s < 0 ){
            perror("simplex-talk:accept");
            exit(1);
          }

          //set new_s to be non-blocking
          fcntl(new_s, NULL, 0);
          //add to master set
          FD_SET(new_s, &master_set);


          //add to client_state_array
          for(int k = 0; k < MAX_CLIENT; k++){
            struct ClientState current = clientStateArray[k];
            if (current.fd == -1){
              clientStateArray[k].fd = new_s;
              clientStateArray[k].shake = 1;
              clientStateArray[k].val = s;
              break;
            }
          }

          //when new_s > fd_max, update fd_max = new_s
        if (new_s > fd_max){
          fd_max = new_s;
        }

      }
      else{
        //loop through client state, find existing fd matching i
        for(int k = 0; k < MAX_CLIENT;k++ ){
          struct ClientState current = clientStateArray[k];
          if (current.fd == i && current.shake == 1){
              //handle first handshake
              handle_first_shake(i);
              //update shake to 2
              clientStateArray[k].shake = 2;
            }
          else if(current.fd == i && current.shake == 2){
              handle_second_shake(i);
              close(i);
              //remove from master set
              FD_CLR(i, &master_set);
              //reinitialize the current struct
              clientStateArray[k].fd = -1;
              clientStateArray[k].shake = -1;
              clientStateArray[k].val= -1;             
            }

          }

        }
      }

      }


  }

}

//Function to handle the first handshake
void handle_first_shake(int new_port){
  char buf[MAX_LINE];
  ssize_t new_s = recv(new_port, buf, sizeof(buf), 0);
  if(new_s < 0){
      perror("simplex-talk: recieve");
      close(new_port);
      exit(1);
    }
  //display the first handshake if something is received
  if(new_s > 0){
    fputs(buf, stdout);
    fputc('\n', stdout);
    fflush(stdout);

    //Scan for int in buffer
    int X;
    char tempForScan[MAX_LINE];
    sscanf(buf, "%s %d", tempForScan, &X);

    int Y = X + 1;
    //Empty buffer for scan
    strcpy(tempForScan, "");
    //Convert Y to string
    sprintf(tempForScan, "%d", Y);
    //Empty buffer and create string to send
    strcpy(buf, "");
    strcpy(buf, "HELLO ");
    strcat(buf, tempForScan);

    //Send to the client
    if(send(new_port, buf, strlen(buf) + 1, 0) < 0){
      perror("Error in sending message.\n");
      close(new_s);
      exit(1);
    }
  } 
}

void handle_second_shake(int new_port){
  char buf[MAX_LINE];
  int len = recv(new_port, buf, sizeof(buf), 0);
  if(len < 0){
    perror("simplex-talk:receive");
    close(new_port);
    exit(1);
  }

  if(len > 0){
    fputs(buf, stdout);
    fputc('\n', stdout);
    fflush(stdout);

  }

}