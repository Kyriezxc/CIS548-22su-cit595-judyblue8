#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "tokenizer.h"
#include <fcntl.h>

#define INPUT_SIZE 1024

pid_t childPid = 0;

void executeShell();

void writeToStdout(char *text);

//void alarmHandler(int sig);

void sigintHandler(int sig);

char **getCommandFromInput();

void registerSignalHandlers();

void killChildProcess();

void redirectionsSTDOUTtoFile( char *tokenAfter);

void redirectionsSTDINtoFile(char* tokenAfter);

void freeDoublePointers(char **doublePtr);

int main(int argc, char **argv) {
    registerSignalHandlers();
    while (1) {        
        executeShell();
    }
    return 0;
}

/* Sends SIGKILL signal to a child process.
 * Error checks for kill system call failure and exits program if
 * there is an error */
void killChildProcess() {
    if (kill(childPid, SIGKILL) == -1) {
        perror("Error in kill");
        exit(EXIT_FAILURE);
    }

}

/* Signal handler for SIGALRM. Catches SIGALRM signal and
 * kills the child process if it exists and is still executing.
 * It then prints out penn-shredder's catchphrase to standard output */
void alarmHandler(int sig) {

    if (sig == SIGALRM){
        if (childPid != 0){
            killChildProcess(); //kill the child process
            childPid = 0; //set the childPid back to 0
            writeToStdout("Bwahaha ... tonight I dine on turtle soup");
        }
    }
}

/* Signal handler for SIGINT. Catches SIGINT signal (e.g. Ctrl + C) and
 * kills the child process if it exists and is executing. Does not
 * do anything to the parent process and its execution */
void sigintHandler(int sig) {
    
    //in parent process
    if (childPid != 0) {
        killChildProcess(); //kill the child process
        //childPid = 0; //set the childPid back to 0
    }

}


/* Registers SIGALRM and SIGINT handlers with corresponding functions.
 * Error checks for signal system call failure and exits program if
 * there is an error */
void registerSignalHandlers() {
    #ifdef DEBUG
        fprintf(stderr, "pid = %d: at line %d in function %s\n", childPid, __LINE__, __func__);
    #endif

    if (signal(SIGINT, sigintHandler) == SIG_ERR) {
        perror("Error in signal");
        exit(EXIT_FAILURE);
    }

    if (signal(SIGALRM, alarmHandler) == SIG_ERR){
        perror("Error in signal");
        exit(EXIT_FAILURE);
    }

}


/* This function redirects the STDOUT of the spcified token to STDOUT
 *Error checks for dup failure and exits program if there is an error.
 */
void redirectionsSTDOUTtoFile( char *tokenAfter){
    //open the file in write only mode
    int new_stdout = open(tokenAfter, O_WRONLY | O_TRUNC | O_CREAT, 0644);
    
    //check for error in opening the file
    if(new_stdout < 0){
        perror("Invalid standard output redirect: No such file or directory");
        exit(EXIT_FAILURE);
    }

    //dup
    int dup2Ret = dup2(new_stdout,STDOUT_FILENO);

    if(dup2Ret == -1){
        perror("Error in redirecting the output.");
        exit(EXIT_FAILURE);
    }

}

/* This function redirects the STDIN of the spcified token to STDOUT
 *Error checks for dup failure and exits program if there is an error.
 */
void redirectionsSTDINtoFile( char *tokenAfter){
    //open the file in write only mode
    int new_stdin = open(tokenAfter, O_RDONLY, 0644);
    
    //check for error in opening the file
    if(new_stdin < 0){
        perror("Invalid standard input redirect: No such file or directory");
        exit(EXIT_FAILURE);
    }

    //dup
    int dup2Ret = dup2(new_stdin,STDIN_FILENO);

    if(dup2Ret == -1){
        perror("Error in redirecting the output.");
        exit(EXIT_FAILURE);
    }

}

/*This functions takes in a double ptr and free it
 *start from the inside later
 */
void freeDoublePointers(char **doublePtr){
    int i = 0;
    while (doublePtr[i] != NULL){
        free(doublePtr[i]);
        i++;
    }
    free(doublePtr);

}


/* Prints the shell prompt and waits for input from user.
 * Takes timeout as an argument and starts an alarm of that timeout period
 * if there is a valid command. It then creates a child process which
 * executes the command with its arguments.
 *
 * The parent process waits for the child. On unsuccessful completion,
 * it exits the shell. */
void executeShell() {
    char **commandArray;
    int status;
    char minishell[] = "penn-sh> ";
    writeToStdout(minishell);

    commandArray = getCommandFromInput();

    
    
    
    if (commandArray != NULL) {
    // printf("The value stored in commandArray[0] is %s\n", commandArray[0]);
    //printf("The value stored in commandArray[1] is %s\n", commandArray[1]);
        
        childPid = fork();

        if (childPid < 0) {
            //free double pointers
            freeDoublePointers(commandArray);
            perror("Error in creating child process");
            exit(EXIT_FAILURE);
        }

        if (childPid == 0) { //Child process
            //initiate commandArray index
            //signal(SIGINT, SIG_IGN);
            int comArrIndex = 0;
            int argIndex = 0;
            
            //initiate counts of redirection symbols
            int inRedirectCount = 0;
            int outRedirectCount = 0;

            //Initiate args array
            char *args [100] = {NULL};

            //circulate through the comArr and populate args
            while(commandArray[comArrIndex] != NULL){

                //printf("The current token is %s\n", commandArray[comArrIndex]);
                //when out is found
                if (strcmp(commandArray[comArrIndex], ">") == 0){
                    //Increment output count
                    outRedirectCount++;
                    
                    //check how many outRediection symbols are there, if more than 1, error
                    if (outRedirectCount > 1){
                        perror("Invalid: Multiple standard output redirects");
                        exit(EXIT_FAILURE);
                    }
                    
                    //otherwise capture the token after the symbol
                    comArrIndex++;
                    redirectionsSTDOUTtoFile(commandArray[comArrIndex]);
                    comArrIndex++;
                    continue;
                }

                //when in is found
                if (strcmp(commandArray[comArrIndex], "<") == 0){
                    //Increment input count
                    inRedirectCount++;
                    
                    //check how many outRediection symbols are there, if more than 1, error
                    if (inRedirectCount > 1){
                        perror("Invalid: Multiple standard input redirects");
                        exit(EXIT_FAILURE);
                    }
                    
                    //otherwise capture the token after the symbol
                    comArrIndex++;
                    redirectionsSTDINtoFile(commandArray[comArrIndex]);
                    comArrIndex++;
                    continue;

                }

                //otherwise add to the arg array
                args[argIndex] = commandArray[comArrIndex];
                argIndex++;
                comArrIndex++;

            }

            //Add null to the end of arg array
            args[argIndex] = NULL;

            //execute commands
            if(execvp(args[0], args) == -1){
                freeDoublePointers(commandArray);
                perror("Error in creating child process");
                exit(EXIT_FAILURE);
            }
        } else {
            do {
                if (wait(&status) == -1) {
 
                    freeDoublePointers(commandArray);
                    perror("Error in child process termination");
                    exit(EXIT_FAILURE);
                }
            } while (!WIFEXITED(status) && !WIFSIGNALED(status));
            childPid = 0;
            
        }
        //free commandArray
        freeDoublePointers(commandArray);
    }

    
}


/* Writes particular text to standard output */
void writeToStdout(char *text) {
    if (write(STDOUT_FILENO, text, strlen(text)) == -1) {
        perror("Error in write");
        exit(EXIT_FAILURE);
    }
}

/* Reads input from standard input till it reaches a new line character.
 * Checks if EOF (Ctrl + D) is being read and exits penn-shredder if that is the case
 * Otherwise, it checks for a valid input and adds the characters to an input buffer.
 *
 * From this input buffer, the first 1023 characters (if more than 1023) or the whole
 * buffer are assigned to command and returned. An \0 is appended to the command so
 * that it is null terminated
 * after getting the command, it will break the command into tokens, and store it into
 * an array of null terminated strings. */
char **getCommandFromInput() {

    /*Creating a char array forbuffer and  return */
    char *buffer = malloc(sizeof(char)*INPUT_SIZE);
    char *command; //=NULL;
    //Separate the string into tokens
    //Initiate a 2D array for return
    char** returnArray;

    /*Check for malloc successful or not*/
    if(buffer == NULL){
        perror("Error in creating reading buffer.");
        exit(EXIT_FAILURE);
    }
    
    /*read in stdin.
    Check for error.
    */
    ssize_t reads = read(STDIN_FILENO, buffer, INPUT_SIZE-1);

    if(reads == -1){
        //In the case when reading is unsuccessful.
        free(buffer);
        perror("Error in read.");
        exit(EXIT_FAILURE);
    }
    
    if(reads == 0){
        //In the case when only controlD is hit, exit directly.
        free(buffer);
        exit(EXIT_SUCCESS);       
    }

    //printf("There are %d characters in the buffer.\n", reads);
    //printf("The command input is %s\n", buffer);

    
    //deal with leading space
    int leading_space_ct = 0;
    for(int i = 0; i < reads;i++){
        if(buffer[i] != ' '){break;}
        leading_space_ct++;
    }
    //printf("There are %d leading spaces\n", leading_space_ct);
    
     //If all white-space, return an empty string 2D array
    if((buffer[reads-1] == '\n') && (reads - 1 == leading_space_ct)){free(buffer); return NULL;}

    //Deal with trailing space
    int trailing_space_ct = 0;
    for(int i = reads-1;i>=0;i--){
        if((buffer[i] != ' ') && (buffer[i] != '\n')){break;}
        trailing_space_ct++;
    }
    
    //printf("There are %d trailing spaces\n", trailing_space_ct);


    
    //Create command for storing the return
    command = malloc(sizeof(char) * (reads + 1));
    int j = 0;
    for(int i = leading_space_ct;i < (reads - trailing_space_ct);i++){
        command[j] = buffer[i];
        j++;
    }

    //Add null to the end of command
    command[j] = '\0';
    
    //printf("The input command is %s\n", command);
    //Free buffer 
    free(buffer);
  
    //Initialize the 2D array
    returnArray = malloc(sizeof(char*) * INPUT_SIZE);
    char **temp = returnArray;

    //Initiate a tokenizer
    TOKENIZER *tokenizer = init_tokenizer(command);
    //check if the tokenizer is null, if not, proceed.
    if(tokenizer != NULL){
            while(1){

        //Get tokenized String and add it to the returnArray
        char* tokenizedString = get_next_token(tokenizer);
        //printf("The current tokenized String is %s\n", tokenizedString);
        *temp = tokenizedString;
        //printf("The string stored in returnArray is now %s\n", *returnArray);
        


        //break the loop if the tokenizedString is NULL
        if (tokenizedString == NULL){
            break;
        }

        //else increment the returnArray
        temp++;

    }
        //free tokenizer
    free_tokenizer(tokenizer);

    //free the command
    free(command);

    //return the array
    return returnArray;
    }
    
    
    return NULL;

}