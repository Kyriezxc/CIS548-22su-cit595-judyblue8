#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "tokenizer.h"
#include <sys/stat.h>
#include <fcntl.h>

#define INPUT_SIZE 1024

pid_t childPid = 0;

void executeShell();

void writeToStdout(char *text);

void alarmHandler(int sig);

void sigintHandler(int sig);

char **getCommandFromInput();

void registerSignalHandlers();

void killChildProcess();

void freeMemory(char** doublePtr);






/* Sends SIGKILL signal to a child process.
 * Error checks for kill system call failure and exits program if
 * there is an error */
void killChildProcess() {
    if (kill(childPid, SIGKILL) == -1) {
        perror("Error in kill");
        exit(EXIT_FAILURE);
    }

}

/* Signal handler for SIGALRM. Catches SIGALRM signal and
 * kills the child process if it exists and is still executing.
 * It then prints out penn-shredder's catchphrase to standard output */
void alarmHandler(int sig) {

    if (sig == SIGALRM){
        if (childPid != 0){
            killChildProcess(); //kill the child process
            childPid = 0; //set the childPid back to 0
            writeToStdout("Bwahaha ... tonight I dine on turtle soup");
        }
    }
}

/* Signal handler for SIGINT. Catches SIGINT signal (e.g. Ctrl + C) and
 * kills the child process if it exists and is executing. Does not
 * do anything to the parent process and its execution */
void sigintHandler(int sig) {
    
    //in parent process
    if (childPid != 0) {
        killChildProcess(); //kill the child process
        childPid = 0; //set the childPid back to 0
    }

}


/* Registers SIGALRM and SIGINT handlers with corresponding functions.
 * Error checks for signal system call failure and exits program if
 * there is an error */
void registerSignalHandlers() {
    #ifdef DEBUG
        fprintf(stderr, "pid = %d: at line %d in function %s\n", childPid, __LINE__, __func__);
    #endif

    if (signal(SIGINT, sigintHandler) == SIG_ERR) {
        perror("Error in signal");
        exit(EXIT_FAILURE);
    }

    if (signal(SIGALRM, alarmHandler) == SIG_ERR){
        perror("Error in signal");
        exit(EXIT_FAILURE);
    }

}


/* Prints the shell prompt and waits for input from user.
 * Takes timeout as an argument and starts an alarm of that timeout period
 * if there is a valid command. It then creates a child process which
 * executes the command with its arguments.
 *
 * The parent process waits for the child. On unsuccessful completion,
 * it exits the shell. */
void executeShell() {
    char **commandArray;
    int status;
    char minishell[] = "penn-sh> ";
    writeToStdout(minishell);

    //get the command and convert it into an array
    commandArray = getCommandFromInput();

    if (commandArray == NULL){
        freeMemory(commandArray);
    }

    if (commandArray == 0){
       freeMemory(commandArray);
        exit(0);
    }


    if (commandArray[0] != NULL) {

        childPid = fork();

        if (childPid < 0) {

            freeMemory(commandArray);
            perror("Error in creating child process");
            exit(EXIT_FAILURE);
        }

        if (childPid == 0)  {
            //in child code 
            signal(SIGINT, SIG_IGN);

            #ifdef DEBUG
                fprintf(stderr, "in child code; pid = %d; at line number %d in function %s\n", childPid, __LINE__, __func__);
            #endif

            //envVariable --> an array of pointers to strings passed as the environment of new program; must be null-terminated
            //args -->args is an array of pointers to strings passed to the new program as its command-line arguments: must be null=terminated
            
            //create the arguement array
            //char** args  = calloc((256) ,sizeof(char*));
            int index = 0;
            int outCounter = 0;
            int inCounter = 0;
            int outIndex = -1;
            int inIndex = -1;

            while (commandArray[index] != NULL){

                if (*commandArray[index] == '>'){
                    outCounter++;
                    outIndex = index;
                }

                if (*commandArray[index] == '<'){
                    inCounter++;
                    inIndex = index;
                }
                index++;
            }

            if (outCounter >1 || inCounter >1){
                perror("invalid input!");
                freeMemory(commandArray);
                exit(EXIT_FAILURE);
            }

            if (outCounter ==1 && inCounter == 0){
                    int new_stdout = open(commandArray[outIndex+1], O_WRONLY | O_TRUNC |  O_CREAT, 0644);
                    dup2(new_stdout, STDOUT_FILENO);

            }
            else if (outCounter == 0 && inCounter ==1){
                    int new_stdin = open(commandArray[inIndex+1], O_RDONLY, 0644);
                    dup2(new_stdin, STDIN_FILENO);
                    
            }
            else if (outCounter == 1 && inCounter ==1){
                    int new_stdout = open(commandArray[outIndex+1], O_WRONLY | O_TRUNC |  O_CREAT, 0644);
                    dup2(new_stdout, STDOUT_FILENO);
                  

                    int new_stdin = open(commandArray[inIndex+1], O_RDONLY, 0644);
                    dup2(new_stdin, STDIN_FILENO);
             
            }

            char* args[INPUT_SIZE] = {NULL};
            if (inIndex != -1){
                for (int i = 0; i<inIndex;i++){
                    args[i] = commandArray[i];
                }
                args[inIndex] = NULL;
            }
            else if (outIndex != -1){
                for (int i = 0; i<outIndex;i++){
                    args[i] = commandArray[i];
                }
                args[outIndex] = NULL;
            }
            else{
                int i = 0;
                while (commandArray[i]!= NULL){
                    args[i] = commandArray[i];
                    i++;
                }
                args[i]= NULL;
            }
            
            if (execvp(args[0], args) == -1){
                freeMemory(commandArray);
                perror("Error in execvp");
                exit(EXIT_FAILURE);
            }
            

        } else {

            //in the parent code

            #ifdef DEBUG 
                fprintf(stderr, "in child code; pid = %d; at line number %d in function %s\n", childPid, __LINE__, __func__);
            #endif

            do {
                if (wait(&status) == -1) {
                    freeMemory(commandArray);
                    perror("Error in child process termination");
                    exit(EXIT_FAILURE);
                }
            } while (!WIFEXITED(status) && !WIFSIGNALED(status));

            childPid = 0; //set childPid back to 0

            #ifdef DEBUG
                fprintf(stderr, "termination status is %d\n", status);
            #endif
        }
    }
    freeMemory(commandArray);
}


/* Writes particular text to standard output */
void writeToStdout(char *text) {
    if (write(STDOUT_FILENO, text, strlen(text)) == -1) {
        perror("Error in write");
        exit(EXIT_FAILURE);
    }
}

void freeMemory(char** doublePtr){
    int i = 0;
    while (doublePtr[i] != NULL){
        free(doublePtr[i]);
        i++;
    }
    free(doublePtr);
}

/* Reads input from standard input till it reaches a new line character.
 * Checks if EOF (Ctrl + D) is being read and exits penn-shredder if that is the case
 * Otherwise, it checks for a valid input and adds the characters to an input buffer.
 *
 * From this input buffer, the first 1023 characters (if more than 1023) or the whole
 * buffer are assigned to command and returned. An \0 is appended to the command so
 * that it is null terminated */
char **getCommandFromInput() {

  char** commandArray = calloc((256) ,sizeof(char*));
  
  char string[256] = "";
  char *tok;
  int br= read( STDIN_FILENO, string, 255);

  string[255] = '\0';	   /* ensure that string is always null-terminated */
  
  //handle ctrl+D without text
  if (br == 0){
      freeMemory(commandArray);
      exit(0);
  }

  if (br  > 0) {

    string[br-1] = '\0';   /* remove trailing \n */
    /* tokenize string */
    TOKENIZER *tokenizer = init_tokenizer( string );
    int index = 0;
    while( (tok = get_next_token( tokenizer )) != NULL ) {
        
      int tokenLength = strlen(tok);
      commandArray[index] = calloc(tokenLength+1,sizeof(char));
      for (int i = 0; tok[i] != '\0'; i++){
          commandArray[index][i] = tok[i];
      }
      commandArray[index][tokenLength] = '\0';
      free( tok );    /* free the token now that we're done with it */
      index++;
    }

    commandArray[index] = NULL;
    free_tokenizer( tokenizer ); /* free memory */
  }
  return commandArray;			/* all's well that end's well */
}



int main(int argc, char **argv) {
    
    //register signal handler
    registerSignalHandlers();
    //while loop for execute shell ()
    while (1) {
        executeShell();
    }

    return 0;
}