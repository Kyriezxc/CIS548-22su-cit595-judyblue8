/* This is a reference socket server implementation that prints out the messages
 * received from clients.
 *
 * It takes two arguments:
 * - server address
 * - server port
 *
 * */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <netinet/ip.h>
#include <pthread.h>
#include <sys/socket.h>

#define MAX_PENDING 10
#define MAX_LINE 100

void *mythread(void *arg);
int main(int argc, char *argv[]) {
  char *host_addr = "127.0.0.1";
  int port = atoi(argv[1]);

  // Hard coded to start 100 threads at max
  pthread_t tids[102];

  /*setup passive open*/
  int s;
  if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
    perror("simplex-talk: socket");
    exit(1);
  }

  /* Config the server address */
  struct sockaddr_in sin;
  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = inet_addr(host_addr);
  sin.sin_port = htons(port);
  // Set all bits of the padding field to 0
  memset(sin.sin_zero, '\0', sizeof(sin.sin_zero));

  /* Bind the socket to the address */
  if ((bind(s, (struct sockaddr *)&sin, sizeof(sin))) < 0) {
    perror("simplex-talk: bind");
    exit(1);
  }

  // connections can be pending if many concurrent client requests
  listen(s, MAX_PENDING);

  /* wait for connection, then receive and print text */
  int new_s;
  socklen_t len = sizeof(sin);
  while (1) {   
    int i;
    for (i = 0; i < 102; i++) {
      // first make new_s accepting inputs from clients
      if ((new_s = accept(s, (struct sockaddr *)&sin, &len)) < 0) {
        perror("simplex-talk: accept");
        exit(1);
      }

      if (pthread_create(&tids[i], NULL, mythread, (void *)(intptr_t)new_s) < 0) {
        perror("error in thread creation");
        exit(1);
      }
    }

     return 0;
  }

  return 0;
}

void *mythread(void *arg) {

  /* wait for connection, then receive and print text */
  int new_s = (intptr_t)arg;
  char buf[MAX_LINE];
  int len;

  if (recv(new_s, buf, sizeof(buf), 0) < 0) {
    perror("simplex-talk:receive");
    close(new_s);
    exit(1);
  }

  fputs(buf, stdout);
  fputc('\n', stdout);
  fflush(stdout);

  // Scan for int in buffer
  int X;
  char tempForScan[MAX_LINE];
  sscanf(buf, "%s %d", tempForScan, &X);

  int Y = X + 1;
  // Empty buffer for scan
  strcpy(tempForScan, "");
  // Convert Y to string
  sprintf(tempForScan, "%d", Y);
  // Empty buffer and create string to send
  strcpy(buf, "");
  strcpy(buf, "HELLO ");
  strcat(buf, tempForScan);

  // Send to the client
  if (send(new_s, buf, strlen(buf) + 1, 0) < 0) {
    perror("Error in sending message.\n");
    close(new_s);
    exit(1);
  }

  // Receive from client for the last time for Z
  // Empty buf
  strcpy(buf, "");
  if (len = recv(new_s, buf, sizeof(buf), 0) <= 0) {
    perror("simplex-talk:receive");
    close(new_s);
    exit(1);
  }
  fputs(buf, stdout);
  fputc('\n', stdout);
  fflush(stdout);

  // check value of Z
  int Z;
  strcpy(tempForScan, "");
  sscanf(buf, "%s %d", tempForScan, &Z);
  if (Z != Y + 1) {
    fputs("ERROR", stdout);
    fputc('\n', stdout);
    fflush(stdout);
    close(new_s);
    exit(1);
  }

  close(new_s);

  // Exit - the current thread terminates
  pthread_exit(NULL);
}