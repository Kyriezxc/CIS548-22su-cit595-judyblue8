#include "pipeFunctions.h"
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* This function redirects the STDOUT of the spcified token to STDOUT
 *Error checks for dup failure and exits program if there is an error.
 */
void redirectionsSTDOUTtoFile(char *tokenAfter) {
  // open the file in write only mode
  int new_stdout = open(tokenAfter, O_WRONLY | O_TRUNC | O_CREAT, 0644);

  // check for error in opening the file
  if (new_stdout < 0) {
    perror("Invalid standard output redirect: No such file or directory");
    exit(EXIT_FAILURE);
    return;
  }

  // dup
  int dup2Ret = dup2(new_stdout, STDOUT_FILENO);

  if (dup2Ret == -1) {
    perror("Error in redirecting the output.");
    exit(EXIT_FAILURE);
    return;
  }
}

/* This function redirects the STDIN of the spcified token to STDOUT
 *Error checks for dup failure and exits program if there is an error.
 */
void redirectionsSTDINtoFile(char *tokenAfter) {
  // open the file in write only mode
  int new_stdin = open(tokenAfter, O_RDONLY, 0644);

  // check for error in opening the file
  if (new_stdin < 0) {
    perror("Invalid standard input redirect: No such file or directory");
    exit(EXIT_FAILURE);
  }

  // dup
  int dup2Ret = dup2(new_stdin, STDIN_FILENO);

  if (dup2Ret == -1) {
    perror("Error in redirecting the output.");
    exit(EXIT_FAILURE);
  }
}

/*This functions takes in a double ptr and free it
 *start from the inside later
 */
void freeDoublePointers(char **doublePtr) {
  int i = 0;
  while (doublePtr[i] != NULL) {
    free(doublePtr[i]);
    i++;
  }
  free(doublePtr);
}

/*This function takes in an array of command, and look for "|" symbol(s).
 *Note that in this project, we are only dealing with two-stage pipes.
 *Thus, the case of having two or more "|" symbols in the command array will be
 *determined as invalid input.
 */

int isPipe(char **commandArray) {
  // Initiate a count of "|" in the commandArray
  int pipeCount = 0;
  int commandIndex = 0;

  // Parse through the input commandArray for pipe symbol(s)
  while (commandArray[commandIndex] != NULL) {
    if (strcmp(commandArray[commandIndex], "|") == 0) {
      pipeCount++;
    }
    commandIndex++;
  }

  // when there is 0 pipeCount, return 0 meaning false
  if (pipeCount == 0) {
    return 0;
  }

  // when there is 1 pipeCount, return 1 meaning true
  if (pipeCount == 1) {
    return 1;
  }

  // by default return -1, meaning more than one pipe, and print error
  return -1;
}

/**This function takes in an array of commandArrays before the piping symbol.
 */
char **createArrayOfTokensBeforePipe(char **commandArray) {
  // initiate the return array with malloc
  char **returnArray = malloc(sizeof(char *) * 100);

  int commandIndex = 0;
  int returnIndex = 0;

  while (strcmp(commandArray[commandIndex], "|") != 0) {
    // Add command to return array until pipe symbol
    returnArray[returnIndex] = malloc(sizeof(char *) * 1024);
    strcpy(returnArray[returnIndex], commandArray[commandIndex]);
    commandIndex++;
    returnIndex++;
  }

  returnArray[returnIndex] = NULL;

  return returnArray;
}

/**This function takes in an array of commandArrays after the piping symbol.
 */
char **createArrayOfTokensAfterPipe(char **commandArray) {
  // initiate the return array with malloc
  char **returnArray = malloc(sizeof(char *) * 100);

  int commandIndex = 0;
  int returnIndex = 0;

  // first locate the pipe symbol in input
  while (strcmp(commandArray[commandIndex], "|") != 0) {
    commandIndex++;
  }

  commandIndex++;

  // then add the command to the returnArray
  while (commandArray[commandIndex] != NULL) {
    // Add command to return array until null
    returnArray[returnIndex] = malloc(sizeof(char) * 1024);
    strcpy(returnArray[returnIndex], commandArray[commandIndex]);
    commandIndex++;
    returnIndex++;
  }

  returnArray[returnIndex] = NULL;
  return returnArray;
}

/*This function takes in an array of commands before the pipe,
 *and deal with redirection symbols. It then return an array of arg if it's
 *valid
 */
char **redirectionsPipeWriterProcess(char **commandArray1) {
  // initiate return array
  char **returnArray = NULL;

  // parse through input commandArrays
  int inputIndex = 0;
  // document the number of input symbols as well as its index
  int inCount = 0;
  int inIndex = 0;

  while (commandArray1[inputIndex] != NULL) {
    // when an input redirection is met, declare invalid and exit
    if (strcmp(commandArray1[inputIndex], ">") == 0) {
      perror("Invalid input: piping and redirction conflicts.");
      // free returnArray
      return NULL;
    }

    if (strcmp(commandArray1[inputIndex], "<") == 0) {
      // when an output redirction is met, increment the count
        inCount++;

        //document the position of the first output redirection symbol
        if (inCount == 1){inIndex = inputIndex;}
    }

    //Othewise continue to parse
    inputIndex++;
  }

  //check if there's more than one input redirection. If yes, return null.
  if (inCount > 1) {
      perror("Invalid input: more than one input redirection found.");
      return NULL;

  }
  
  //if there is no output redirection, symply populate the return array.
  //initiate the return array
  returnArray = malloc(sizeof(char*) * 100);
  if (inCount == 0){
      //reset inputIndex to be 0
      inputIndex = 0;

      //set up index for return array
      int returnIndex = 0;
      //parse and populate return array.
      while(commandArray1[inputIndex] != NULL){
          returnArray[returnIndex] = malloc(sizeof(char) * 100);
          strcpy(returnArray[returnIndex], commandArray1[inputIndex]);
          inputIndex++;
          returnIndex++;
      }

      //make sure the return array ends with NULL
      returnArray[returnIndex] = NULL;
  }

  //if there is one output redirection, populate the array before the redirection symbol
  if (inCount == 1){
      inputIndex = 0;

      int returnIndex = 0;
      //parse through the array until NULL or redirection symbol
      while(commandArray1[inputIndex] != NULL){
          if(inputIndex == inIndex){break;}
          //populatet the return array if not null or not out redirection symbol
          returnArray[returnIndex] = malloc(sizeof(char) * 100);
          strcpy(returnArray[returnIndex], commandArray1[inputIndex]);
          inputIndex++;
          returnIndex++;
      }

      //make sure the return array ends with null
      returnArray[returnIndex] = NULL;

      //redirect the output accordingly
      //first check if the command after redirection is null
      if(commandArray1[inIndex + 1] != NULL){
          redirectionsSTDINtoFile(commandArray1[inIndex + 1]);

      }
      

  }

  //last, check if returnArray is empty, if yes return NULL
  if(returnArray[0] == NULL){return NULL;}


  return returnArray;
}



/*This function takes in an array of commands before the pipe,
 *and deal with redirection symbols. It then return an array of arg if it's
 *valid
 */
char **redirectionsPipeReaderProcess(char **commandArray2) {
  // initiate return array
  char **returnArray = NULL;

  // parse through input commandArrays
  int inputIndex = 0;
  // document the number of output symbols as well as its index
  int outCount = 0;
  int outIndex = 0;

  while (commandArray2[inputIndex] != NULL) {
    // when an input redirection is met, declare invalid and exit
    if (strcmp(commandArray2[inputIndex], "<") == 0) {
      perror("Invalid input: piping and redirction conflicts.");
      // free returnArray
      return NULL;
    }

    if (strcmp(commandArray2[inputIndex], ">") == 0) {
      // when an output redirction is met, increment the count
        outCount++;

        //document the position of the first output redirection symbol
        if (outCount == 1){outIndex = inputIndex;}
    }

    //Othewise continue to parse
    inputIndex++;
  }

  //check if there's more than one output redirection. If yes, return null.
  if (outCount > 1) {
      perror("Invalid input: more than one output redirection found.");
      return NULL;

  }
  
  //if there is no output redirection, symply populate the return array.
  //initiate the return array
  returnArray = malloc(sizeof(char*) * 100);
  if (outCount == 0){
      //reset inputIndex to be 0
      inputIndex = 0;

      //set up index for return array
      int returnIndex = 0;
      //parse and populate return array.
      while(commandArray2[inputIndex] != NULL){
          returnArray[returnIndex] = malloc(sizeof(char) * 100);
          strcpy(returnArray[returnIndex], commandArray2[inputIndex]);
          inputIndex++;
          returnIndex++;
      }

      //make sure the return array ends with NULL
      returnArray[returnIndex] = NULL;
  }

  //if there is one output redirection, populate the array before the redirection symbol
  if (outCount == 1){
      inputIndex = 0;

      int returnIndex = 0;
      //parse through the array until NULL or redirection symbol
      while(commandArray2[inputIndex] != NULL){
          if(inputIndex == outIndex){break;}
          //populatet the return array if not null or not out redirection symbol
          returnArray[returnIndex] = malloc(sizeof(char) * 100);
          strcpy(returnArray[returnIndex], commandArray2[inputIndex]);
          inputIndex++;
          returnIndex++;
      }

      //make sure the return array ends with null
      returnArray[returnIndex] = NULL;

      //redirect the output accordingly
      //first check if the command after redirection is null
      if(commandArray2[outIndex + 1] != NULL){
          redirectionsSTDOUTtoFile(commandArray2[outIndex + 1]);

      }
      

  }

  //last, check if returnArray is empty, if yes return NULL
  if(returnArray[0] == NULL){return NULL;}


  return returnArray;
}
