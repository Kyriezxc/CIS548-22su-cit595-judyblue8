#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void freeDoublePointers(char **doublePtr);

void redirectionsSTDOUTtoFile( char *tokenAfter);

void redirectionsSTDINtoFile(char* tokenAfter);

void freeDoublePointers(char **doublePtr);

//Determine if there is a valid piping symbol in input array
int isPipe(char** commandArray);

//This function returns an array of commands before the valid pipe symbol
char** createArrayOfTokensBeforePipe (char** commandArray);

//This function returns an array of commands after the valid pipe symbol
char** createArrayOfTokensAfterPipe (char** commandArray);

//This function returns the args array for writer process if the innput is not null
char** redirectionsPipeWriterProcess(char** commandArray1);

//This function returns the args array for reader process if the innput is not null
char** redirectionsPipeReaderProcess(char** commandArray2);
