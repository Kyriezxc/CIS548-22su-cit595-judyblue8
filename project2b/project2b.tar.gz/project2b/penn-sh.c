#include "pipeFunctions.h"
#include "tokenizer.h"
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define INPUT_SIZE 1024

pid_t childPid = 0;

pid_t childPid1 = 0;

pid_t childPid2 = 0;

void executeShell();

void writeToStdout(char *text);

// void alarmHandler(int sig);

void sigintHandler(int sig);

char **getCommandFromInput();

void registerSignalHandlers();

void killChildProcess();

void project2aExecustion(char **commandArray);

int main(int argc, char **argv) {
  registerSignalHandlers();
  while (1) {
    executeShell();
  }
  return 0;
}

/* Sends SIGKILL signal to a child process.
 * Error checks for kill system call failure and exits program if
 * there is an error */
void killChildProcess() {
  if (kill(childPid, SIGKILL) == -1) {
    perror("Error in kill");
    exit(EXIT_FAILURE);
  }
}

/* Signal handler for SIGALRM. Catches SIGALRM signal and
 * kills the child process if it exists and is still executing.
 * It then prints out penn-shredder's catchphrase to standard output */
void alarmHandler(int sig) {

  if (sig == SIGALRM) {
    if (childPid != 0) {
      killChildProcess(); // kill the child process
      childPid = 0;       // set the childPid back to 0
      writeToStdout("Bwahaha ... tonight I dine on turtle soup");
    }
  }
}

/* Signal handler for SIGINT. Catches SIGINT signal (e.g. Ctrl + C) and
 * kills the child process if it exists and is executing. Does not
 * do anything to the parent process and its execution */
void sigintHandler(int sig) {

  // in parent process
  if (childPid != 0) {
    killChildProcess(); // kill the child process
    // childPid = 0; //set the childPid back to 0
  }
}

/* Registers SIGALRM and SIGINT handlers with corresponding functions.
 * Error checks for signal system call failure and exits program if
 * there is an error
 */
void registerSignalHandlers() {
#ifdef DEBUG
  fprintf(stderr, "pid = %d: at line %d in function %s\n", childPid, __LINE__,
          __func__);
#endif

  if (signal(SIGINT, sigintHandler) == SIG_ERR) {
    perror("Error in signal");
    exit(EXIT_FAILURE);
  }

  if (signal(SIGALRM, alarmHandler) == SIG_ERR) {
    perror("Error in signal");
    exit(EXIT_FAILURE);
  }
}

/*
This function executes the shell as directed by project2a (no piping)
*/
void project2aExecustion(char **commandArray) {
  // printf("The value stored in commandArray[0] is %s\n", commandArray[0]);
  // printf("The value stored in commandArray[1] is %s\n", commandArray[1]);

  int status;
  int childPid = fork();

  if (childPid < 0) {
    // free double pointers
    freeDoublePointers(commandArray);
    perror("Error in creating child process");
    exit(EXIT_FAILURE);
  }

  if (childPid == 0) { // Child process
    // initiate commandArray index
    // signal(SIGINT, SIG_IGN);
    int comArrIndex = 0;
    int argIndex = 0;

    // initiate counts of redirection symbols
    int inRedirectCount = 0;
    int outRedirectCount = 0;

    // Initiate args array
    char *args[100] = {NULL};

    // circulate through the comArr and populate args
    while (commandArray[comArrIndex] != NULL) {

      // printf("The current token is %s\n", commandArray[comArrIndex]);
      // when out is found
      if (strcmp(commandArray[comArrIndex], ">") == 0) {
        // Increment output count
        outRedirectCount++;

        // check how many outRediection symbols are there, if more than 1, error
        if (outRedirectCount > 1) {
          perror("Invalid: Multiple standard output redirects");
          // free double pointers
          freeDoublePointers(commandArray);
          exit(EXIT_FAILURE);
        }

        // otherwise capture the token after the symbol
        comArrIndex++;
        redirectionsSTDOUTtoFile(commandArray[comArrIndex]);
        comArrIndex++;
        continue;
      }

      // when in is found
      if (strcmp(commandArray[comArrIndex], "<") == 0) {
        // Increment input count
        inRedirectCount++;

        // check how many outRediection symbols are there, if more than 1, error
        if (inRedirectCount > 1) {
          perror("Invalid: Multiple standard input redirects");
          freeDoublePointers(commandArray);
          exit(EXIT_FAILURE);
        }

        // otherwise capture the token after the symbol
        comArrIndex++;
        redirectionsSTDINtoFile(commandArray[comArrIndex]);
        comArrIndex++;
        continue;
      }

      // otherwise add to the arg array
      args[argIndex] = commandArray[comArrIndex];
      argIndex++;
      comArrIndex++;
    }

    // Add null to the end of arg array
    args[argIndex] = NULL;

    // execute commands
    if (execvp(args[0], args) == -1) {
      freeDoublePointers(commandArray);
      perror("Error in creating child process");
      exit(EXIT_FAILURE);
    }
  } else {
    do {
      if (wait(&status) == -1) {

        freeDoublePointers(commandArray);
        perror("Error in child process termination");
        exit(EXIT_FAILURE);
      }
    } while (!WIFEXITED(status) && !WIFSIGNALED(status));
    childPid = 0;
  }

  freeDoublePointers(commandArray);

}

/* Prints the shell prompt and waits for input from user.
 * Takes timeout as an argument and starts an alarm of that timeout period
 * if there is a valid command. It then creates a child process which
 * executes the command with its arguments.
 *
 * The parent process waits for the child. On unsuccessful completion,
 * it exits the shell. */
void executeShell() {
  char **commandArray;
  char minishell[] = "penn-sh> ";
  int piping = 0;
  writeToStdout(minishell);

  commandArray = getCommandFromInput();

  if (commandArray != NULL) {

    // check if there is piping
    piping = isPipe(commandArray);

    // in the case when there is invalid piping input
    if (piping < 0) {
      perror("Invalid: more than two staged pipes.");
      // free commandArray
      freeDoublePointers(commandArray);
      exit(EXIT_FAILURE);
    }

    // in the case when there is no need for piping. execute 2a
    if (piping == 0) {
      project2aExecustion(commandArray);
    }

    if (piping == 1) {
      // documenting status of childProcess 1 and 2
      int status1;
      int status2;
      // get commands before and after the pipe first.
      char **commandArray1;
      char **commandArray2;

      commandArray1 = createArrayOfTokensBeforePipe(commandArray);
      commandArray2 = createArrayOfTokensAfterPipe(commandArray);
      //printf("The second command is %s\n", commandArray2[0]);
      //free commandArray
      freeDoublePointers(commandArray);

      // create file descriptor
      int fd[2];
      int pipeCall = pipe(fd);

      // In the case when piping call fails
      if (pipeCall < 0) {
        perror("Error in pipe call.");
        freeDoublePointers(commandArray1);
        freeDoublePointers(commandArray2);
        exit(EXIT_FAILURE);
      }

      // create child process 1
      childPid1 = fork();

      // check if the forking is successful
      if (childPid1 < 0) {
        perror("Error in forking process for child 1.");
        // free memories
        freeDoublePointers(commandArray1);
        freeDoublePointers(commandArray2);
        exit(EXIT_FAILURE);
      }

      if (childPid1 == 0) { // In child process 1, aka the writer process
        // initiate an array for storing the return args1
        char **args1 = redirectionsPipeWriterProcess(commandArray1);
        //printf("The first command in arg1 is %s\n", args1[0]);
        //printf("The second command in arg1 is %s\n", args1[1]);
        //free commandArray1
        freeDoublePointers(commandArray1);

        // check if the returned args1 is NULL, if yes, exit with failure
        if (args1 == NULL) {
          // free memory
          freeDoublePointers(commandArray2);
          exit(EXIT_FAILURE);
        }

        // otherwise close the read end of the file
        close(fd[0]);

        // then connect the write end to the stdin
        int dup2Ret1 = dup2(fd[1], STDOUT_FILENO);
        if (dup2Ret1 < 0) {
          perror("Error in dup2 proccess in child1.");
          // freememory
          freeDoublePointers(commandArray2);
          freeDoublePointers(args1);
          exit(EXIT_FAILURE);
        }

        //close the pipe
        close(fd[1]);
        
        //printf("Line 312 here \n");
        // execute
        if (execvp(args1[0], args1) == -1) {
          freeDoublePointers(commandArray2);
          freeDoublePointers(args1);
          perror("Error in executing child process1");
          exit(EXIT_FAILURE);
        }
        //free args1
        freeDoublePointers(args1);
      }

      // proceed to childprocess number 2
      childPid2 = fork();

      // check for forking error:
      if (childPid2 < 0) {
        perror("Error in creating child process 2.");
        // free memory
        freeDoublePointers(commandArray2);
        // exit
        exit(EXIT_FAILURE);
      }

      if (childPid2 == 0) { // childprocess 2
        // initiate an array for storing the return args1
        char **args2 = redirectionsPipeReaderProcess(commandArray2);
        //printf("The first command in arg2 is %s line 339\n", args2[0]);
        //free commandArray[2]
        freeDoublePointers(commandArray2);

        // check if the returned args1 is NULL, if yes, exit with failure
        if (args2 == NULL) {
          // free memory
          exit(EXIT_FAILURE);
        }

        // otherwise close the write end of the file
        close(fd[1]);
        // then connect the write end to the stdin
        int dup2Ret2 = dup2(fd[0], STDIN_FILENO);
        if (dup2Ret2 < 0) {
          perror("Error in dup2 proccess in child1.");
          // freememory
          freeDoublePointers(args2);
          exit(EXIT_FAILURE);
        }

        close(fd[0]);

        // execute
        if (execvp(args2[0], args2) == -1) {
          freeDoublePointers(args2);
          perror("Error in executing child process2");
          exit(EXIT_FAILURE);
        }
        //free args2
        freeDoublePointers(args2);
      }


      if ((childPid2 != 0) && (childPid1 != 0)) { // parent process
       //close parental pipe
       close(fd[1]);
        do {
          if (waitpid(childPid1,&status1,0) == -1) {
            // free mem if error in child process 1 termination.
            freeDoublePointers(commandArray);
            freeDoublePointers(commandArray1);
            freeDoublePointers(commandArray2);
            perror("Error in child process 1 termination");
            exit(EXIT_FAILURE);
          }
          if (waitpid(childPid2, &status2,0) == -1) {
            // free mem if error in child process 2 termination.
            freeDoublePointers(commandArray);
            freeDoublePointers(commandArray1);
            freeDoublePointers(commandArray2);
            perror("Error in child process 2 termination");
            exit(EXIT_FAILURE);
          }
        } while ((!WIFEXITED(status1) &&
                 !WIFSIGNALED(status1)) || (!WIFEXITED(status2) &&
                 !WIFSIGNALED(status2)));
        childPid1 = 0;
        childPid2 = 0;
      }

      //freecommands
      freeDoublePointers(commandArray1);
      freeDoublePointers(commandArray2);
      //freeDoublePointers(commandArray);
    }
  }
}

/* Writes particular text to standard output */
void writeToStdout(char *text) {
  if (write(STDOUT_FILENO, text, strlen(text)) == -1) {
    perror("Error in write");
    exit(EXIT_FAILURE);
  }
}

/* Reads input from standard input till it reaches a new line character.
 * Checks if EOF (Ctrl + D) is being read and exits penn-shredder if that is the
 * case Otherwise, it checks for a valid input and adds the characters to an
 * input buffer.
 *
 * From this input buffer, the first 1023 characters (if more than 1023) or the
 * whole buffer are assigned to command and returned. An \0 is appended to the
 * command so that it is null terminated after getting the command, it will
 * break the command into tokens, and store it into
 * an array of null terminated strings. */
char **getCommandFromInput() {

  /*Creating a char array forbuffer and  return */
  char *buffer = malloc(sizeof(char) * INPUT_SIZE);
  char *command; //=NULL;
  // Separate the string into tokens
  // Initiate a 2D array for return
  char **returnArray;

  /*Check for malloc successful or not*/
  if (buffer == NULL) {
    perror("Error in creating reading buffer.");
    exit(EXIT_FAILURE);
  }

  /*read in stdin.
  Check for error.
  */
  ssize_t reads = read(STDIN_FILENO, buffer, INPUT_SIZE - 1);

  if (reads == -1) {
    // In the case when reading is unsuccessful.
    free(buffer);
    perror("Error in read.");
    exit(EXIT_FAILURE);
  }

  if (reads == 0) {
    // In the case when only controlD is hit, exit directly.
    free(buffer);
    exit(EXIT_SUCCESS);
  }

  // printf("There are %d characters in the buffer.\n", reads);
  // printf("The command input is %s\n", buffer);

  // deal with leading space
  int leading_space_ct = 0;
  for (int i = 0; i < reads; i++) {
    if (buffer[i] != ' ') {
      break;
    }
    leading_space_ct++;
  }
  // printf("There are %d leading spaces\n", leading_space_ct);

  // If all white-space, return an empty string 2D array
  if ((buffer[reads - 1] == '\n') && (reads - 1 == leading_space_ct)) {
    free(buffer);
    return NULL;
  }

  // Deal with trailing space
  int trailing_space_ct = 0;
  for (int i = reads - 1; i >= 0; i--) {
    if ((buffer[i] != ' ') && (buffer[i] != '\n')) {
      break;
    }
    trailing_space_ct++;
  }

  // printf("There are %d trailing spaces\n", trailing_space_ct);

  // Create command for storing the return
  command = malloc(sizeof(char) * (reads + 1));
  int j = 0;
  for (int i = leading_space_ct; i < (reads - trailing_space_ct); i++) {
    command[j] = buffer[i];
    j++;
  }

  // Add null to the end of command
  command[j] = '\0';

  // printf("The input command is %s\n", command);
  // Free buffer
  free(buffer);

  // Initialize the 2D array
  returnArray = malloc(sizeof(char *) * INPUT_SIZE);
  char **temp = returnArray;

  // Initiate a tokenizer
  TOKENIZER *tokenizer = init_tokenizer(command);
  // check if the tokenizer is null, if not, proceed.
  if (tokenizer != NULL) {
    while (1) {

      // Get tokenized String and add it to the returnArray
      char *tokenizedString = get_next_token(tokenizer);
      // printf("The current tokenized String is %s\n", tokenizedString);
      *temp = tokenizedString;
      // printf("The string stored in returnArray is now %s\n", *returnArray);

      // break the loop if the tokenizedString is NULL
      if (tokenizedString == NULL) {
        break;
      }

      // else increment the returnArray
      temp++;
    }
    // free tokenizer
    free_tokenizer(tokenizer);

    // free the command
    free(command);

    // return the array
    return returnArray;
  }

  return NULL;
}